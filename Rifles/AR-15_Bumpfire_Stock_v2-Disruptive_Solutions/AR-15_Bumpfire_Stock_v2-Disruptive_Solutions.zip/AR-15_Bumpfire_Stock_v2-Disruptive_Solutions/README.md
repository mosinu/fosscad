# Disruptive Solutions AR15 Slidefire stock v2

#### Description

Looking through a thread about printing a bump fire stock I saw a lot of interest in printing one, but no one with a model of one, so heres that model. the spring/grip plug is just a cut down pistol grip and functions the same as the traditional slidefire stock. I wasn't able to find pictures of the actual internal retention mechanism used in the original slidefire stock So I had to improvise there and used a variation of the collapsing stock I designed for my lower receiver. As of yet this stock does not have the ability to lock in place for traditional semi-automatic fire. The stock mechanism itself attaches to a normal commercial carbine buffer tube. This stock has yet to be printed/tested. Model has been updated for printing in 8x8x8 print beds and all correct files included. 

#### File List:

* Stock body 1.igs
* Stock body 2.igs
* Stock body 3.igs
* Grip Plug.igs
* Stock body 1.stl
* Stock body 2.stl
* Stock body 3.stl
* Grip Plug.stl
* Bumpfirestock1.jpg
* Bumpfirestock2.jpg
* Bumpfirestock3.jpg
* grip plug.jpg
* README.txt

All Files are provided as is and open source. For help/support visit: http://fosscad.org/chat
